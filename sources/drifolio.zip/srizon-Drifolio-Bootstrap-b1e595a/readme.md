<a href="http://creatrix.us/demo/drifolio/"><img src="http://shapebootstrap.net/wp-content/uploads/2014/11/Drifolio-Free-Responsive-Dribbble-Portfolio-Template-cover.jpg" alt="Drifolio – Free Responsive Dribbble Portfolio Template"></a>

What & Why Drifolio?
---------------------------
Drifolio - stands for Dribbble Portfolio.

There are many designers around me don't have enough time to setup and manage their own website. For them it could be a great template that needs one time setup.

You just need to set your info and dribbble username, that's all. And after that, whenever you post something on dribbble, it'll come automatically to your website as well. There's nothing to do there again :)

Live demo: http://demo.evenfly.com/view?theme=Drifolio

View the post on dribbble: http://drbl.in/mVHv

Also available on ShapeBootstrap:
http://shapebootstrap.net/item/drifolio-free-responsive-dribbble-portfolio-template/

This is a free Bootstrap powered HTML template from EvenFly. Feel free to download, modify and use it for yourself or your clients as long there is no money involved.

Please don't try to sale it from anywhere; because I want it to be free, forever. If you sale it, that's me who deserves the money, not you :)

Documentetion and credits
---------------------------
Here is a short documentetion about basic changes on the template
http://goo.gl/FhmJav

Feel free to drop an email to support@evenfly.com
if you have any question/suggestions.


THANKS!
---------------------------
If you like this template, you may like our other products as well.
Keep your eyes on 
http://evenfly.com

Or follow us on
https://www.facebook.com/evenflyteam or 
https://twitter.com/EvenFlyTeam
