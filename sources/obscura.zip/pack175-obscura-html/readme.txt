This resource has been created by elemis for http://elemisfreebies.com


TERMS OF USE:

All royalty free stock layered PSD’s (except web templates), patterns, textures, design elements, themes and other design resources on this website are free for use in both personal and commercial projects .

You may freely use them in software programs, iPhone skins, scrapbooking kits, web templates, Themeforest themes, websites, print on demand sites such as Zazzle, blogs, etc.

You may redistribute them within projects such as those listed above, but not by themselves as is.

If you use/modify the resources in your projects please linkback to the resource page. (Please don’t link directly to the .zip files, please link to the resource page.)

If you should have any questions please contact us here: http://elemisfreebies.com/contact/


-elemis
Visit our portfolio: http://elemisfreebies.com/portfolio

